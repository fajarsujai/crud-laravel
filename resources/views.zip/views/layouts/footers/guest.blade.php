<footer class="py-5">
    <div class="container">
        @include('layouts.footers.nav')
    </div>
</footer>